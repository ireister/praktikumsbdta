<?php
   $hostname  = "localhost";
   $username  = "root";
   $password  = "";
   $dbname  = "penyewaanps";

   $db = new mysqli($hostname, $username, $password, $dbname);
?>